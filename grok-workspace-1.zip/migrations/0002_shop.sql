create table if not exists profiles (
  user_id text primary key,
  name text not null,
  phone text not null default '',
  role text not null default 'cliente',
  created_at timestamptz not null default now(),
  constraint profiles_role_chk check (role in ('cliente', 'funcionario', 'dono'))
);

create unique index if not exists profiles_one_owner
  on profiles (role) where role = 'dono';

create table if not exists shop_settings (
  id integer primary key,
  name text not null,
  tagline text not null,
  intro text not null,
  about text not null,
  whatsapp text not null default '',
  address text not null default '',
  hours text not null default '',
  constraint shop_settings_one check (id = 1)
);

create table if not exists services (
  id serial primary key,
  name text not null,
  description text not null,
  price_label text not null default 'A confirmar',
  image text not null,
  sort_order integer not null default 0,
  visible boolean not null default true
);

create sequence if not exists order_no_seq;

create table if not exists orders (
  id text primary key,
  user_id text not null,
  client_name text not null,
  phone text not null default '',
  service_name text not null,
  qty integer not null default 1,
  note text not null default '',
  status text not null default 'Recebido',
  payment text not null default 'Pendente',
  file_name text not null default '',
  file_data text,
  final_name text not null default '',
  final_data text,
  assignee text not null default '',
  created_at timestamptz not null default now(),
  constraint orders_status_chk check (status in ('Recebido', 'Em produção', 'A aguardar pagamento', 'Concluído')),
  constraint orders_payment_chk check (payment in ('Pendente', 'Comprovativo enviado', 'Pago'))
);

create index if not exists orders_user_idx on orders (user_id);

create sequence if not exists payment_no_seq;

create table if not exists payments (
  id text primary key,
  order_id text not null,
  user_id text not null,
  method text not null,
  status text not null default 'Por verificar',
  amount_aoa integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists payments_order_idx on payments (order_id);

create table if not exists messages (
  id serial primary key,
  thread_user_id text not null,
  author_id text not null,
  author_name text not null,
  author_role text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create index if not exists messages_thread_idx on messages (thread_user_id, created_at);

create table if not exists promotions (
  id serial primary key,
  title text not null,
  body text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into shop_settings (id, name, tagline, intro, about, whatsapp, address, hours)
values (
  1,
  'PRO GRÁFICA',
  'As tuas ideias ganham forma.',
  'Envia o documento, acompanha o pedido e levanta o trabalho — ou descarrega o ficheiro final aqui.',
  'Impressão, cópias, design, cartões, digitalização, encadernação e plastificação. Os preços oficiais são os que a gráfica publicar neste portal.',
  '',
  '',
  ''
)
on conflict (id) do nothing;

insert into services (name, description, price_label, image, sort_order, visible)
select v.name, v.description, v.price_label, v.image, v.sort_order, v.visible
from (values
  ('Impressão e cópias'::text, 'Documentos a preto e branco ou a cores.'::text, 'A confirmar'::text, '/photos/impressao.jpg'::text, 1::int, true::boolean),
  ('Design gráfico'::text, 'Criação e preparação de artes gráficas.'::text, 'A confirmar'::text, '/photos/design.jpg'::text, 2::int, true::boolean),
  ('Cartões e convites'::text, 'Materiais personalizados para eventos.'::text, 'A confirmar'::text, '/photos/cartoes.jpg'::text, 3::int, true::boolean),
  ('Digitalização'::text, 'Conversão de documentos para ficheiros digitais.'::text, 'A confirmar'::text, '/photos/digitalizacao.jpg'::text, 4::int, true::boolean),
  ('Encadernação'::text, 'Organização e acabamento de documentos.'::text, 'A confirmar'::text, '/photos/encadernacao.jpg'::text, 5::int, true::boolean),
  ('Plastificação'::text, 'Proteção e acabamento de documentos.'::text, 'A confirmar'::text, '/photos/plastificacao.jpg'::text, 6::int, true::boolean)
) as v(name, description, price_label, image, sort_order, visible)
where not exists (select 1 from services);
