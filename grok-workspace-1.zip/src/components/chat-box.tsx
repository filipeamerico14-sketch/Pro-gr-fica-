import { useEffect, useRef, useState } from "react";
import type { ChatMessage } from "@/lib/shop-types";
import { formatWhen } from "@/lib/format";

export function ChatBox({
  messages,
  mineId,
  onSend,
  busy,
}: {
  messages: ChatMessage[];
  mineId: string;
  onSend: (text: string) => Promise<void>;
  busy: boolean;
}) {
  const [text, setText] = useState("");
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = box.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [messages.length]);

  return (
    <div>
      <div ref={box} className="grid max-h-80 gap-2 overflow-auto rounded-lg bg-paper p-3">
        {messages.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted">Ainda não há mensagens.</p>
        ) : (
          messages.map((message) => {
            const mine = message.authorId === mineId;
            return (
              <div
                key={message.id}
                className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${mine ? "ml-auto bg-ink text-paper" : "border border-line bg-sheet"}`}
              >
                <p className="text-xs opacity-70">
                  {message.authorName} · {formatWhen(message.createdAt)}
                </p>
                <p className="mt-1 whitespace-pre-wrap">{message.body}</p>
              </div>
            );
          })
        )}
      </div>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          const value = text.trim();
          if (!value) return;
          void onSend(value).then(() => setText(""));
        }}
      >
        <input
          className="field-input"
          value={text}
          onChange={(event) => setText(event.target.value)}
          placeholder="Escreve uma mensagem"
          maxLength={1000}
        />
        <button className="btn btn-primary" type="submit" disabled={busy}>
          Enviar
        </button>
      </form>
    </div>
  );
}
