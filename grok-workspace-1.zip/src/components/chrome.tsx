import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getSessionContext } from "@/lib/shop.functions";

export function Logo({ name, inverse = false }: { name: string; inverse?: boolean }) {
  return (
    <span className="inline-flex min-w-0 items-center gap-3">
      <svg viewBox="0 0 64 64" className="size-11 shrink-0 text-brass" aria-hidden="true">
        <path
          d="M6 18V6h12M46 6h12v12M58 46v12H46M18 58H6V46"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.6"
        />
        <rect x="16" y="16" width="32" height="32" rx="8" className={inverse ? "fill-paper" : "fill-ink"} />
        <text
          x="32"
          y="37"
          textAnchor="middle"
          fontSize="14"
          fontFamily="Fraunces, Georgia, serif"
          className={inverse ? "fill-ink" : "fill-paper"}
        >
          PG
        </text>
      </svg>
      <span className="min-w-0 leading-none">
        <span className={`block truncate font-display text-lg ${inverse ? "text-paper" : "text-ink"}`}>
          {name}
        </span>
        <span className={`kicker mt-1 block ${inverse ? "text-brass" : ""}`}>Impressão · Design</span>
      </span>
    </span>
  );
}

function AuthSlot() {
  const [mounted, setMounted] = useState(false);
  const { user, isPending } = useCurrentUserState();
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    if (!user) return;
    let dead = false;
    getSessionContext()
      .then((ctx) => {
        if (!dead) setRole(ctx.role);
      })
      .catch(() => {
        if (!dead) setRole(null);
      });
    return () => {
      dead = true;
    };
  }, [user?.id]);

  if (!mounted || isPending) {
    return <div className="h-11 w-36 animate-pulse rounded-full bg-line" />;
  }
  if (!user) {
    return (
      <div className="flex items-center gap-2">
        <Link to="/login" search={{ tab: "entrar", next: "" }} className="btn btn-secondary">
          Entrar
        </Link>
        <Link to="/login" search={{ tab: "registo", next: "" }} className="btn btn-primary">
          Criar conta
        </Link>
      </div>
    );
  }
  const staff = role === "dono" || role === "funcionario";
  return (
    <div className="flex min-w-0 items-center gap-2">
      <Link
        to={staff ? "/grafica" : "/conta"}
        search={staff ? undefined : { servico: "" }}
        className="btn btn-secondary"
      >
        {staff ? "Painel" : "A minha conta"}
      </Link>
      <div className="min-w-0 overflow-hidden">
        <UserButton />
      </div>
    </div>
  );
}

export function Header({ name }: { name: string }) {
  return (
    <header className="no-print sticky top-0 z-20 border-b border-line bg-paper/90 backdrop-blur-md">
      <div className="h-1 bg-brass" />
      <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link to="/" aria-label="PRO GRÁFICA, início" className="min-w-0">
          <Logo name={name} />
        </Link>
        <nav className="hidden items-center gap-6 text-sm md:flex">
          <a href="/#servicos">Serviços</a>
          <a href="/#processo">Processo</a>
          <a href="/#contacto">Contacto</a>
        </nav>
        <div className="flex items-center gap-2">
          <details className="relative md:hidden">
            <summary className="menu-sum flex size-11 items-center justify-center rounded-full border border-line bg-sheet">
              <Menu className="size-5" />
              <span className="sr-only">Menu</span>
            </summary>
            <div className="absolute right-0 z-30 mt-2 grid w-48 gap-1 rounded-xl border border-line bg-sheet p-2">
              <a className="rounded-lg px-3 py-2" href="/#servicos">Serviços</a>
              <a className="rounded-lg px-3 py-2" href="/#processo">Processo</a>
              <a className="rounded-lg px-3 py-2" href="/#contacto">Contacto</a>
            </div>
          </details>
          <AuthSlot />
        </div>
      </div>
    </header>
  );
}

export function Footer({ name }: { name: string }) {
  return (
    <footer className="no-print mt-16 bg-ink text-paper">
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 md:grid-cols-3">
        <Logo name={name} inverse />
        <p className="max-w-sm text-sm text-paper/80">
          Portal de pedidos da gráfica. Cria uma conta de cliente, envia o ficheiro e acompanha o trabalho.
        </p>
        <div className="text-sm">
          <p className="kicker">Equipa</p>
          <Link to="/grafica" className="mt-3 inline-block text-paper underline-offset-4 hover:underline">
            Área da gráfica
          </Link>
          <p className="mt-2 max-w-xs text-paper/70">
            O acesso de funcionário não está no registo. Só o dono pode atribuí-lo.
          </p>
        </div>
      </div>
      <p className="border-t border-paper/15 px-4 py-4 text-center text-sm text-paper/70">
        {name} · Angola
      </p>
    </footer>
  );
}

export function PageSkeleton() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="h-8 w-48 animate-pulse rounded-md bg-line" />
      <div className="mt-6 h-44 animate-pulse rounded-xl bg-line" />
    </div>
  );
}

export function Empty({ children }: { children: string }) {
  return <p className="py-8 text-center text-sm text-muted">{children}</p>;
}
