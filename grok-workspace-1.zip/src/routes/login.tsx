import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { authClient, GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { phoneOk } from "@/lib/format";
import { getPublicShop, saveProfile } from "@/lib/shop.functions";
import { Footer, Header, PageSkeleton } from "@/components/chrome";
import { useEffect } from "react";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>) => ({
    tab: search.tab === "registo" ? ("registo" as const) : ("entrar" as const),
    next: search.next === "grafica" ? ("grafica" as const) : ("" as const),
  }),
  loader: () => getPublicShop(),
  component: LoginPage,
});

function authMessage(error: { message?: string } | null | undefined) {
  const msg = error?.message || "";
  if (/exist/i.test(msg)) return "Já existe uma conta com este e-mail. Entra em vez de criar outra.";
  if (/password/i.test(msg)) return "A palavra-passe precisa de pelo menos 8 caracteres.";
  if (/email/i.test(msg)) return "E-mail inválido.";
  if (/origin/i.test(msg)) return "Não foi possível validar este acesso. Tenta outra vez.";
  if (/invalid/i.test(msg)) return "E-mail ou palavra-passe incorretos.";
  return msg || "Não foi possível concluir. Tenta outra vez.";
}

function LoginPage() {
  const shop = Route.useLoaderData();
  const search = Route.useSearch();
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <div className="flex min-h-screen flex-col">
      <Header name={shop.settings.name} />
      <main className="mx-auto w-full max-w-lg flex-1 px-4 py-12">
        {!mounted || isPending ? (
          <PageSkeleton />
        ) : user ? (
          <AlreadyIn />
        ) : (
          <AuthCard initial={search.tab} next={search.next} />
        )}
      </main>
      <Footer name={shop.settings.name} />
    </div>
  );
}

function AlreadyIn() {
  return (
    <div className="panel">
      <p className="kicker">Sessão</p>
      <h1 className="section-title mt-2">Já estás dentro</h1>
      <p className="mt-3 text-sm text-muted">A tua conta de cliente não escolhe o perfil de funcionário. Esse acesso só o dono atribui.</p>
      <div className="mt-6 flex flex-wrap gap-2">
        <Link to="/conta" search={{ servico: "" }} className="btn btn-primary">
          A minha conta
        </Link>
        <Link to="/grafica" className="btn btn-secondary">
          Área da gráfica
        </Link>
      </div>
    </div>
  );
}

function AuthCard({ initial, next }: { initial: "entrar" | "registo"; next: "" | "grafica" }) {
  const [mode, setMode] = useState(initial);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const navigate = useNavigate();

  async function goNext() {
    await router.invalidate();
    if (next === "grafica") {
      await navigate({ to: "/grafica" });
      return;
    }
    let service = "";
    try {
      service = sessionStorage.getItem("pg.servico") || "";
    } catch {
      service = "";
    }
    await navigate({ to: "/conta", search: { servico: service } });
  }

  async function onRegister(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    if (name.trim().length < 2) return setError("Indica o teu nome.");
    if (!phoneOk(phone)) return setError("Indica um telefone válido, com indicativo se quiseres.");
    if (!email.includes("@")) return setError("Indica um e-mail válido.");
    if (password.length < 8) return setError("A palavra-passe precisa de pelo menos 8 caracteres.");
    if (password !== confirm) return setError("As palavras-passe não coincidem.");
    setBusy(true);
    try {
      const result = await authClient.signUp.email({
        email: email.trim(),
        password,
        name: name.trim(),
      });
      if (result.error) {
        setError(authMessage(result.error));
        return;
      }
      try {
        await saveProfile({ data: { name: name.trim(), phone: phone.trim() } });
      } catch {
        /* a conta pede o telefone outra vez se falhar */
      }
      await goNext();
    } catch (err) {
      setError(authMessage(err instanceof Error ? err : { message: "" }));
    } finally {
      setBusy(false);
    }
  }

  async function onEnter(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    if (!email.includes("@") || password.length < 8) {
      setError("Confere o e-mail e a palavra-passe.");
      return;
    }
    setBusy(true);
    try {
      const result = await authClient.signIn.email({ email: email.trim(), password });
      if (result.error) {
        setError(authMessage(result.error));
        return;
      }
      await goNext();
    } catch (err) {
      setError(authMessage(err instanceof Error ? err : { message: "" }));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel">
      <p className="kicker">Conta de cliente</p>
      <h1 className="section-title mt-2">{mode === "registo" ? "Criar conta" : "Entrar"}</h1>
      <p className="mt-3 text-sm text-muted">
        O registo é sempre de cliente. Não há opção para entrar como funcionário — esse acesso só o dono da gráfica pode dar, depois de a pessoa ter conta.
      </p>
      <div className="mt-5 flex gap-2">
        <button type="button" className={mode === "entrar" ? "btn btn-primary" : "btn btn-secondary"} onClick={() => setMode("entrar")}>
          Entrar
        </button>
        <button type="button" className={mode === "registo" ? "btn btn-primary" : "btn btn-secondary"} onClick={() => setMode("registo")}>
          Criar conta
        </button>
      </div>
      <form className="mt-6 grid gap-3" onSubmit={mode === "registo" ? onRegister : onEnter}>
        {mode === "registo" ? (
          <>
            <label className="field">
              <span>Nome completo</span>
              <input className="field-input" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
            </label>
            <label className="field">
              <span>Telefone</span>
              <input className="field-input" value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" placeholder="+244 9XX XXX XXX" />
            </label>
          </>
        ) : null}
        <label className="field">
          <span>E-mail</span>
          <input className="field-input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </label>
        <label className="field">
          <span>Palavra-passe</span>
          <input
            className="field-input"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={mode === "registo" ? "new-password" : "current-password"}
          />
        </label>
        {mode === "registo" ? (
          <label className="field">
            <span>Confirmar palavra-passe</span>
            <input className="field-input" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
          </label>
        ) : null}
        {error ? (
          <p role="alert" className="rounded-lg bg-bad-soft px-3 py-2 text-sm text-bad">
            {error}
          </p>
        ) : null}
        <button className="btn btn-primary" type="submit" disabled={busy}>
          {busy ? "A aguardar…" : mode === "registo" ? "Criar conta de cliente" : "Entrar"}
        </button>
      </form>
      <div className="mt-6 grid gap-2">
        {GROK_PROVIDERS.map((provider) => (
          <button
            key={provider.providerId}
            type="button"
            className="btn btn-secondary w-full"
            onClick={() => {
              void signIn(provider.providerId, { callbackURL: next === "grafica" ? "/grafica" : "/conta" }).catch((err: unknown) => {
                setError(authMessage(err instanceof Error ? err : { message: "" }));
              });
            }}
          >
            Continuar com {provider.label}
          </button>
        ))}
      </div>
    </div>
  );
}
