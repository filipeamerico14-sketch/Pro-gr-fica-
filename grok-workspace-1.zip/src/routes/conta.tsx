import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { readUpload } from "@/lib/files";
import { explain, formatWhen, phoneOk } from "@/lib/format";
import {
  createOrder,
  getOrderAsset,
  getPublicShop,
  getSessionContext,
  listMessages,
  listOrders,
  listPayments,
  saveProfile,
  sendMessage,
  submitPayment,
} from "@/lib/shop.functions";
import { PAYMENT_METHODS, type OrderSummary, type PaymentRow, type SessionContext } from "@/lib/shop-types";
import { ChatBox } from "@/components/chat-box";
import { Empty, Footer, Header, PageSkeleton } from "@/components/chrome";

export const Route = createFileRoute("/conta")({
  validateSearch: (search: Record<string, unknown>) => ({
    servico: typeof search.servico === "string" ? search.servico.slice(0, 80) : "",
  }),
  loader: () => getPublicShop(),
  component: ContaPage,
});

const TABS = [
  ["resumo", "Resumo"],
  ["novo", "Novo pedido"],
  ["pedidos", "Pedidos"],
  ["ficheiros", "Documentos"],
  ["pagamentos", "Pagamentos"],
  ["chat", "Atendimento"],
] as const;

type Tab = (typeof TABS)[number][0];

function ContaPage() {
  const shop = Route.useLoaderData();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const { user, isPending } = useCurrentUserState();

  return (
    <div className="flex min-h-screen flex-col">
      <Header name={shop.settings.name} />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
        {!mounted || isPending ? (
          <PageSkeleton />
        ) : !user ? (
          <RedirectToSignIn />
        ) : (
          <ContaInner />
        )}
      </main>
      <Footer name={shop.settings.name} />
    </div>
  );
}

function ContaInner() {
  const shop = Route.useLoaderData();
  const search = Route.useSearch();
  const { user } = useCurrentUserState();
  const [ctx, setCtx] = useState<SessionContext | null>(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<Tab>("resumo");
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    if (!user) return;
    let dead = false;
    getSessionContext()
      .then((next) => {
        if (!dead) setCtx(next);
      })
      .catch((err: unknown) => {
        if (!dead) setError(explain(err));
      });
    return () => {
      dead = true;
    };
  }, [user?.id, nonce]);

  if (!user) return null;
  if (error) return <p className="text-bad">{error}</p>;
  if (!ctx) return <PageSkeleton />;
  if (!ctx.role) {
    return <CompleteProfile fallbackName={user.displayName || ""} onDone={() => setNonce((n) => n + 1)} />;
  }
  if (ctx.role !== "cliente") return <Navigate to="/grafica" />;

  return (
    <div>
      <p className="kicker">Cliente</p>
      <h1 className="section-title mt-2">Olá, {ctx.name}</h1>
      <p className="mt-2 text-muted">Acompanha os teus pedidos. O estado e o ficheiro final aparecem aqui.</p>
      <div className="no-print mt-6 flex gap-2 overflow-x-auto pb-2">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            type="button"
            className={tab === id ? "btn btn-primary" : "btn btn-secondary"}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="mt-6">
        {tab === "resumo" ? <Resumo /> : null}
        {tab === "novo" ? <NovoPedido services={shop.services} preset={search.servico} onCreated={() => setTab("pedidos")} /> : null}
        {tab === "pedidos" ? <Pedidos /> : null}
        {tab === "ficheiros" ? <Ficheiros /> : null}
        {tab === "pagamentos" ? <Pagamentos /> : null}
        {tab === "chat" ? <Chat mineId={user.id} /> : null}
      </div>
    </div>
  );
}

function CompleteProfile({ fallbackName, onDone }: { fallbackName: string; onDone: () => void }) {
  const [name, setName] = useState(fallbackName);
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <form
      className="panel max-w-lg"
      onSubmit={(event) => {
        event.preventDefault();
        if (name.trim().length < 2) return setError("Indica o teu nome.");
        if (!phoneOk(phone)) return setError("Indica um telefone válido.");
        setBusy(true);
        setError("");
        void saveProfile({ data: { name: name.trim(), phone: phone.trim() } })
          .then(() => onDone())
          .catch((err: unknown) => setError(explain(err)))
          .finally(() => setBusy(false));
      }}
    >
      <p className="kicker">Conta de cliente</p>
      <h1 className="section-title mt-2">Completa o teu perfil</h1>
      <p className="mt-2 text-sm text-muted">Esta conta fica como cliente. Não há escolha de funcionário.</p>
      <label className="field mt-4">
        <span>Nome</span>
        <input className="field-input" value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <label className="field">
        <span>Telefone</span>
        <input className="field-input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+244 9XX XXX XXX" />
      </label>
      {error ? <p className="text-sm text-bad">{error}</p> : null}
      <button className="btn btn-primary mt-2" disabled={busy} type="submit">
        {busy ? "A guardar…" : "Guardar"}
      </button>
    </form>
  );
}

function useOrders() {
  const [orders, setOrders] = useState<OrderSummary[] | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let dead = false;
    listOrders()
      .then((rows) => {
        if (!dead) setOrders(rows);
      })
      .catch((err: unknown) => {
        if (!dead) setError(explain(err));
      });
    return () => {
      dead = true;
    };
  }, []);
  return { orders, error, setOrders };
}

async function download(orderId: string, kind: "source" | "final") {
  const file = await getOrderAsset({ data: { orderId, kind } });
  const link = document.createElement("a");
  link.href = file.dataUrl;
  link.download = file.name || "ficheiro";
  link.click();
}

function Resumo() {
  const { orders, error } = useOrders();
  if (error) return <p className="text-bad">{error}</p>;
  if (!orders) return <PageSkeleton />;
  const stats = [
    ["Pedidos", orders.length],
    ["Em produção", orders.filter((o) => o.status === "Em produção").length],
    ["Concluídos", orders.filter((o) => o.status === "Concluído").length],
    ["Ficheiros finais", orders.filter((o) => o.hasFinal).length],
  ];
  return (
    <div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {stats.map(([label, value]) => (
          <article key={String(label)} className="panel">
            <p className="text-sm text-muted">{label}</p>
            <p className="mt-2 font-display text-3xl tabular-nums">{value}</p>
          </article>
        ))}
      </div>
      <div className="mt-6 grid gap-3">
        {orders.slice(0, 5).map((order) => (
          <OrderCard key={order.id} order={order} />
        ))}
        {orders.length === 0 ? <Empty>Ainda não tens pedidos.</Empty> : null}
      </div>
    </div>
  );
}

function NovoPedido({
  services,
  preset,
  onCreated,
}: {
  services: { name: string }[];
  preset: string;
  onCreated: () => void;
}) {
  const [service, setService] = useState(services[0]?.name || "");
  const [qty, setQty] = useState(1);
  const [note, setNote] = useState("");
  const [phone, setPhone] = useState("");
  const [fileName, setFileName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getSessionContext()
      .then((ctx) => setPhone(ctx.phone))
      .catch(() => undefined);
  }, []);
  useEffect(() => {
    if (preset && services.some((item) => item.name === preset)) setService(preset);
  }, [preset, services]);

  if (services.length === 0) return <Empty>Ainda não há serviços visíveis no catálogo.</Empty>;

  return (
    <form
      className="panel max-w-2xl"
      onSubmit={(event) => {
        event.preventDefault();
        const input = event.currentTarget;
        const file = input.querySelector<HTMLInputElement>('input[type="file"]')?.files?.[0];
        if (!phoneOk(phone)) return setError("Indica um telefone válido.");
        if (!note.trim() && !file) return setError("Escreve instruções ou anexa um ficheiro.");
        setBusy(true);
        setError("");
        void (async () => {
          try {
            const upload = file ? await readUpload(file) : { name: "", dataUrl: "" };
            const result = await createOrder({
              data: {
                serviceName: service,
                qty,
                note,
                phone,
                fileName: upload.name,
                fileData: upload.dataUrl,
              },
            });
            try {
              sessionStorage.removeItem("pg.servico");
            } catch {
              /* ignore */
            }
            toast.success(`Pedido ${result.id} registado.`);
            onCreated();
          } catch (err) {
            setError(explain(err));
          } finally {
            setBusy(false);
          }
        })();
      }}
    >
      <div className="grid gap-3 md:grid-cols-2">
        <label className="field">
          <span>Serviço</span>
          <select className="field-input" value={service} onChange={(e) => setService(e.target.value)}>
            {services.map((item) => (
              <option key={item.name}>{item.name}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Quantidade</span>
          <input className="field-input" type="number" min={1} max={5000} value={qty} onChange={(e) => setQty(Number(e.target.value))} />
        </label>
      </div>
      <label className="field">
        <span>Telefone de contacto</span>
        <input className="field-input" value={phone} onChange={(e) => setPhone(e.target.value)} />
      </label>
      <label className="field">
        <span>Instruções</span>
        <textarea className="field-area" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Tamanho, cores, papel, prazo…" />
      </label>
      <label className="field">
        <span>Documento</span>
        <input
          className="text-sm"
          type="file"
          onChange={(e) => setFileName(e.target.files?.[0]?.name || "")}
        />
        <span className="text-xs text-muted">{fileName || "PDF ou imagem até 600 KB."}</span>
      </label>
      {error ? <p className="text-sm text-bad">{error}</p> : null}
      <button className="btn btn-primary" disabled={busy} type="submit">
        {busy ? "A enviar…" : "Enviar pedido"}
      </button>
    </form>
  );
}

function Pedidos() {
  const { orders, error } = useOrders();
  if (error) return <p className="text-bad">{error}</p>;
  if (!orders) return <PageSkeleton />;
  if (orders.length === 0) return <Empty>Ainda não há pedidos.</Empty>;
  return (
    <div className="grid gap-3">
      {orders.map((order) => (
        <OrderCard key={order.id} order={order} />
      ))}
    </div>
  );
}

function Ficheiros() {
  const { orders, error } = useOrders();
  const ready = useMemo(() => orders?.filter((order) => order.hasFinal) ?? [], [orders]);
  if (error) return <p className="text-bad">{error}</p>;
  if (!orders) return <PageSkeleton />;
  if (ready.length === 0) return <Empty>Ainda não há documentos finalizados.</Empty>;
  return (
    <div className="grid gap-3">
      {ready.map((order) => (
        <article key={order.id} className="panel flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-medium">{order.id}</p>
            <p className="text-sm text-muted">{order.finalName || order.serviceName}</p>
          </div>
          <button className="btn btn-secondary" type="button" onClick={() => void download(order.id, "final").catch((err: unknown) => toast.error(explain(err)))}>
            Descarregar
          </button>
        </article>
      ))}
    </div>
  );
}

function Pagamentos() {
  const { orders } = useOrders();
  const [rows, setRows] = useState<PaymentRow[] | null>(null);
  const [orderId, setOrderId] = useState("");
  const [method, setMethod] = useState<(typeof PAYMENT_METHODS)[number]>(PAYMENT_METHODS[0]);
  const [amount, setAmount] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    listPayments()
      .then(setRows)
      .catch((err: unknown) => setError(explain(err)));
  }, []);
  useEffect(() => {
    if (!orderId && orders?.[0]) setOrderId(orders[0].id);
  }, [orders, orderId]);

  return (
    <div className="grid gap-4">
      <form
        className="panel max-w-xl"
        onSubmit={(event) => {
          event.preventDefault();
          if (!orderId) return setError("Ainda não tens um pedido para associar.");
          setBusy(true);
          setError("");
          void submitPayment({
            data: { orderId, method, amount: amount ? Number(amount) : 0 },
          })
            .then((next) => {
              setRows(next);
              toast.success("Pagamento registado. A gráfica confirma antes de o dar como pago.");
            })
            .catch((err: unknown) => setError(explain(err)))
            .finally(() => setBusy(false));
        }}
      >
        <h2 className="font-display text-2xl">Registar pagamento</h2>
        <p className="mt-2 text-sm text-muted">
          Multicaixa Express, transferência ou pagamento na loja. O comprovativo podes enviá-lo no atendimento.
        </p>
        <label className="field mt-4">
          <span>Pedido</span>
          <select className="field-input" value={orderId} onChange={(e) => setOrderId(e.target.value)}>
            {(orders || []).map((order) => (
              <option key={order.id} value={order.id}>
                {order.id} · {order.serviceName}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Método</span>
          <select className="field-input" value={method} onChange={(e) => setMethod(e.target.value as (typeof PAYMENT_METHODS)[number])}>
            {PAYMENT_METHODS.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Valor em AOA (opcional)</span>
          <input className="field-input" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))} />
        </label>
        {error ? <p className="text-sm text-bad">{error}</p> : null}
        <button className="btn btn-primary" disabled={busy} type="submit">
          {busy ? "A registar…" : "Registar"}
        </button>
      </form>
      <div className="grid gap-2">
        {(rows || []).map((row) => (
          <p key={row.id} className="panel text-sm">
            {row.orderId} · {row.method} · {row.status}
            {row.amountAoa ? ` · ${row.amountAoa} AOA` : ""}
          </p>
        ))}
        {rows && rows.length === 0 ? <Empty>Sem pagamentos registados.</Empty> : null}
      </div>
    </div>
  );
}

function Chat({ mineId }: { mineId: string }) {
  const [messages, setMessages] = useState<Awaited<ReturnType<typeof listMessages>>>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    listMessages({ data: { threadUserId: "" } })
      .then(setMessages)
      .catch((err: unknown) => toast.error(explain(err)));
  }, []);
  return (
    <div className="panel">
      <ChatBox
        messages={messages}
        mineId={mineId}
        busy={busy}
        onSend={async (body) => {
          setBusy(true);
          try {
            setMessages(await sendMessage({ data: { threadUserId: "", body } }));
          } catch (err) {
            toast.error(explain(err));
          } finally {
            setBusy(false);
          }
        }}
      />
    </div>
  );
}

function OrderCard({ order }: { order: OrderSummary }) {
  return (
    <article className="panel">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-medium">{order.id}</p>
          <p className="text-sm text-muted">
            {order.serviceName} · {order.qty} · {formatWhen(order.createdAt)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <span className="pill">{order.status}</span>
          <span className={order.payment === "Pago" ? "pill pill-good" : "pill pill-warn"}>{order.payment}</span>
        </div>
      </div>
      {order.note ? <p className="mt-3 whitespace-pre-wrap text-sm">{order.note}</p> : null}
      <div className="mt-3 flex flex-wrap gap-2">
        {order.hasFile ? (
          <button className="btn btn-secondary" type="button" onClick={() => void download(order.id, "source").catch((err: unknown) => toast.error(explain(err)))}>
            O meu ficheiro
          </button>
        ) : null}
        {order.hasFinal ? (
          <button className="btn btn-primary" type="button" onClick={() => void download(order.id, "final").catch((err: unknown) => toast.error(explain(err)))}>
            Ficheiro final
          </button>
        ) : null}
      </div>
    </article>
  );
}
