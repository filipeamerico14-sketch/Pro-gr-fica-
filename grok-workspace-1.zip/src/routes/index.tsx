import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { HERO_IMAGE } from "@/lib/catalog";
import { waHref } from "@/lib/format";
import { getPublicShop } from "@/lib/shop.functions";
import { Footer, Header } from "@/components/chrome";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  loader: () => getPublicShop(),
  component: Home,
});

function Home() {
  const shop = Route.useLoaderData();
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const whatsapp = waHref(shop.settings.whatsapp);

  function pedir(service: string) {
    try {
      sessionStorage.setItem("pg.servico", service);
    } catch {
      /* ignore */
    }
    void navigate({ to: "/conta", search: { servico: service } });
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header name={shop.settings.name} />
      <main className="flex-1">
        <section className="mx-auto grid w-full max-w-6xl items-center gap-10 px-4 py-12 md:grid-cols-2 md:py-20">
          <div>
            <p className="kicker">Oficina de impressão</p>
            <h1 className="display mt-4">{shop.settings.tagline}</h1>
            <span className="rule" />
            <p className="max-w-xl text-lg text-muted">{shop.settings.intro}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button className="btn btn-primary" type="button" onClick={() => pedir("")}>
                Enviar documento
              </button>
              <a className="btn btn-secondary" href="#servicos">
                Ver serviços
              </a>
            </div>
          </div>
          <figure className="shot relative">
            <div className="aspect-[16/10] overflow-hidden rounded-xl bg-ink-soft">
              <img
                src={HERO_IMAGE}
                alt="Mesa de trabalho de design gráfico com amostras de cor"
                className="h-full w-full object-cover"
                fetchPriority="high"
              />
            </div>
            <figcaption className="absolute bottom-4 left-4 rounded-lg bg-ink px-4 py-3 text-sm text-paper">
              Impressão · Design · Acabamento
            </figcaption>
          </figure>
        </section>

        {mounted && !isPending && user && !shop.ownerReady ? (
          <section className="mx-auto w-full max-w-6xl px-4">
            <div className="panel flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="kicker">Configuração</p>
                <h2 className="mt-2 font-display text-2xl">A gráfica ainda não tem dono</h2>
                <p className="mt-2 max-w-xl text-sm text-muted">
                  Se és o responsável, abre a área da gráfica e introduz o código que te foi entregue.
                  Quem cria conta no site entra sempre como cliente.
                </p>
              </div>
              <Link to="/grafica" className="btn btn-primary">
                Ativar painel do dono
              </Link>
            </div>
          </section>
        ) : null}

        {shop.promotions.length > 0 ? (
          <section className="mx-auto mt-12 grid w-full max-w-6xl gap-4 px-4 md:grid-cols-3">
            {shop.promotions.slice(0, 3).map((promo) => (
              <article key={promo.id} className="panel">
                <p className="kicker">Promoção</p>
                <h2 className="mt-2 font-display text-2xl">{promo.title}</h2>
                <p className="mt-2 whitespace-pre-wrap text-sm text-muted">{promo.body}</p>
              </article>
            ))}
          </section>
        ) : null}

        <section id="servicos" className="mx-auto w-full max-w-6xl px-4 py-16 md:py-24">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="kicker">O que fazemos</p>
              <h2 className="section-title mt-2">Catálogo</h2>
            </div>
            <p className="max-w-sm text-sm text-muted">Os preços são os publicados pela gráfica. Enquanto não houver tabela, ficam a confirmar.</p>
          </div>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {shop.services.length === 0 ? (
              <p className="text-muted">O catálogo está a ser atualizado.</p>
            ) : (
              shop.services.map((service) => (
                <article key={service.id} className="shot overflow-hidden rounded-xl border border-line bg-sheet">
                  <div className="aspect-[4/3] bg-line">
                    <img src={service.image} alt="" className="h-full w-full object-cover" loading="lazy" />
                  </div>
                  <div className="p-5">
                    <h3 className="font-display text-2xl">{service.name}</h3>
                    <p className="mt-2 text-sm text-muted">{service.description}</p>
                    <p className={`mt-4 ${service.priceLabel === "A confirmar" ? "text-muted" : "font-medium"}`}>
                      {service.priceLabel}
                    </p>
                    <button className="btn btn-secondary mt-4" type="button" onClick={() => pedir(service.name)}>
                      Pedir este serviço
                    </button>
                  </div>
                </article>
              ))
            )}
          </div>
        </section>

        <section id="processo" className="bg-ink text-paper">
          <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-16 md:grid-cols-3 md:py-20">
            {[
              ["01", "Envia", "Cria a conta de cliente e anexa o documento ou descreve o que precisas."],
              ["02", "Acompanha", "A equipa atualiza o estado: recebido, em produção ou concluído."],
              ["03", "Recebe", "Descarrega o ficheiro final ou levanta o trabalho na gráfica."],
            ].map(([n, title, text]) => (
              <div key={n}>
                <p className="font-display text-4xl text-brass">{n}</p>
                <h2 className="mt-3 font-display text-3xl">{title}</h2>
                <p className="mt-2 text-paper/75">{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto grid w-full max-w-6xl items-center gap-8 px-4 py-16 md:grid-cols-2 md:py-24">
          <div className="shot aspect-[4/3] overflow-hidden rounded-xl bg-line">
            <img
              src="/photos/encadernacao.jpg"
              alt="Livros alinhados, prontos para acabamento"
              className="h-full w-full object-cover"
              loading="lazy"
            />
          </div>
          <div>
            <p className="kicker">A casa</p>
            <h2 className="section-title mt-2">Sobre a gráfica</h2>
            <span className="rule" />
            <p className="whitespace-pre-wrap text-muted">{shop.settings.about}</p>
          </div>
        </section>

        <section id="contacto" className="mx-auto w-full max-w-6xl px-4 pb-8">
          <p className="kicker">Contacto</p>
          <h2 className="section-title mt-2">Onde estamos</h2>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <article className="panel">
              <h3 className="font-medium">Morada</h3>
              <p className="mt-2 text-sm text-muted">{shop.settings.address || "A morada ainda vai ser publicada."}</p>
            </article>
            <article className="panel">
              <h3 className="font-medium">Horário</h3>
              <p className="mt-2 text-sm text-muted">{shop.settings.hours || "O horário ainda vai ser publicado."}</p>
            </article>
            <article className="panel">
              <h3 className="font-medium">WhatsApp</h3>
              {whatsapp ? (
                <a className="btn btn-primary mt-4" href={whatsapp} target="_blank" rel="noreferrer">
                  Falar no WhatsApp
                </a>
              ) : (
                <p className="mt-2 text-sm text-muted">O número oficial ainda vai ser publicado.</p>
              )}
            </article>
          </div>
        </section>
      </main>
      <Footer name={shop.settings.name} />
    </div>
  );
}
