import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { isAllowedImage } from "@/lib/catalog";
import {
  ORDER_STATUSES,
  PAYMENT_METHODS,
  isOneOf,
  type ChatMessage,
  type EditorData,
  type OrderSummary,
  type PaymentRow,
  type Promotion,
  type PublicShop,
  type ReportData,
  type Role,
  type SessionContext,
  type ShopService,
  type ShopSettings,
  type TeamMember,
  type ThreadSummary,
} from "@/lib/shop-types";

const MAX_DATA_URL = 900_000;

function obj(input: unknown): Record<string, unknown> {
  if (!input || typeof input !== "object") throw new Error("Dados inválidos.");
  return input as Record<string, unknown>;
}

function str(value: unknown, max: number) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function must(value: string, message: string) {
  if (!value) throw new Error(message);
  return value;
}

function asNum(value: unknown) {
  if (typeof value === "bigint") return Number(value);
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function asBool(value: unknown) {
  return value === true || value === 1 || value === "1" || value === "t" || value === "true";
}

function asIso(value: unknown) {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string") return value;
  return "";
}

function asRole(value: string): Role | null {
  if (value === "cliente" || value === "funcionario" || value === "dono") return value;
  return null;
}

function intBetween(value: unknown, min: number, max: number, fallback: number) {
  const n = Math.round(asNum(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function phoneDigitsOk(phone: string) {
  return phone.replace(/\D/g, "").length >= 9;
}

function safeName(name: string) {
  const base = name.split(/[/\\]/).pop() || "ficheiro";
  return base.replace(/[^\w.\- ()áàâãéêíóôõúçÁÀÂÃÉÊÍÓÔÕÚÇ]+/g, "").slice(0, 160) || "ficheiro";
}

function fileOrNull(dataUrl: string, name: string) {
  if (!dataUrl) return { data: null as string | null, name: "" };
  if (!dataUrl.startsWith("data:") || dataUrl.length > MAX_DATA_URL) {
    throw new Error("O ficheiro é demasiado grande (máximo cerca de 600 KB) ou não é válido.");
  }
  return { data: dataUrl, name: safeName(name) };
}

type Profile = { userId: string; name: string; phone: string; role: Role };

async function profileOf(userId: string): Promise<Profile | null> {
  const sql = await getSql();
  const rows = await sql<{ user_id: string; name: string; phone: string; role: string }>`
    select user_id, name, phone, role from profiles where user_id = ${userId} limit 1
  `;
  const row = rows[0];
  if (!row) return null;
  const role = asRole(row.role);
  if (!role) return null;
  return { userId: row.user_id, name: row.name, phone: row.phone, role };
}

async function requireRole(userId: string, roles: Role[]) {
  const profile = await profileOf(userId);
  if (!profile || !roles.includes(profile.role)) {
    throw new Error("Sem permissão para esta ação.");
  }
  return profile;
}

function mapSettings(row: {
  name: string;
  tagline: string;
  intro: string;
  about: string;
  whatsapp: string;
  address: string;
  hours: string;
}): ShopSettings {
  return {
    name: row.name,
    tagline: row.tagline,
    intro: row.intro,
    about: row.about,
    whatsapp: row.whatsapp,
    address: row.address,
    hours: row.hours,
  };
}

function mapService(row: {
  id: unknown;
  name: string;
  description: string;
  price_label: string;
  image: string;
  sort_order: unknown;
  visible: unknown;
}): ShopService {
  return {
    id: asNum(row.id),
    name: row.name,
    description: row.description,
    priceLabel: row.price_label,
    image: row.image,
    sortOrder: asNum(row.sort_order),
    visible: asBool(row.visible),
  };
}

function mapOrder(row: {
  id: string;
  user_id: string;
  client_name: string;
  phone: string;
  service_name: string;
  qty: unknown;
  note: string;
  status: string;
  payment: string;
  file_name: string;
  final_name: string;
  assignee: string;
  created_at: unknown;
  has_file: unknown;
  has_final: unknown;
}): OrderSummary {
  return {
    id: row.id,
    userId: row.user_id,
    clientName: row.client_name,
    phone: row.phone,
    serviceName: row.service_name,
    qty: asNum(row.qty),
    note: row.note,
    status: row.status,
    payment: row.payment,
    fileName: row.file_name,
    finalName: row.final_name,
    assignee: row.assignee,
    createdAt: asIso(row.created_at),
    hasFile: asBool(row.has_file),
    hasFinal: asBool(row.has_final),
  };
}

const ORDER_SELECT = `
  id, user_id, client_name, phone, service_name, qty, note, status, payment,
  file_name, final_name, assignee, created_at,
  (coalesce(file_data, '') <> '') as has_file,
  (coalesce(final_data, '') <> '') as has_final
`;

async function readSettings(): Promise<ShopSettings> {
  const sql = await getSql();
  const rows = await sql<{
    name: string;
    tagline: string;
    intro: string;
    about: string;
    whatsapp: string;
    address: string;
    hours: string;
  }>`select name, tagline, intro, about, whatsapp, address, hours from shop_settings where id = 1`;
  if (!rows[0]) throw new Error("Configuração da gráfica em falta.");
  return mapSettings(rows[0]);
}

async function readServices(all: boolean): Promise<ShopService[]> {
  const sql = await getSql();
  const rows = all
    ? await sql<Parameters<typeof mapService>[0]>`
        select id, name, description, price_label, image, sort_order, visible
        from services order by sort_order, id
      `
    : await sql<Parameters<typeof mapService>[0]>`
        select id, name, description, price_label, image, sort_order, visible
        from services where visible = true order by sort_order, id
      `;
  return rows.map(mapService);
}

async function readPromos(all: boolean): Promise<Promotion[]> {
  const sql = await getSql();
  const rows = all
    ? await sql<{ id: unknown; title: string; body: string; active: unknown }>`
        select id, title, body, active from promotions order by id desc
      `
    : await sql<{ id: unknown; title: string; body: string; active: unknown }>`
        select id, title, body, active from promotions where active = true order by id desc
      `;
  return rows.map((row) => ({
    id: asNum(row.id),
    title: row.title,
    body: row.body,
    active: asBool(row.active),
  }));
}

async function ownerReady() {
  const sql = await getSql();
  const rows = await sql`select 1 as ok from profiles where role = 'dono' limit 1`;
  return rows.length > 0;
}

async function editorData(): Promise<EditorData> {
  const [settings, services, promotions] = await Promise.all([
    readSettings(),
    readServices(true),
    readPromos(true),
  ]);
  return { settings, services, promotions };
}

async function ordersFor(userId: string): Promise<OrderSummary[]> {
  const me = await profileOf(userId);
  if (!me) return [];
  const sql = await getSql();
  const list =
    me.role === "cliente"
      ? await sql.query<Parameters<typeof mapOrder>[0]>(
          `select ${ORDER_SELECT} from orders where user_id = $1 order by created_at desc limit 200`,
          [userId],
        )
      : await sql.query<Parameters<typeof mapOrder>[0]>(
          `select ${ORDER_SELECT} from orders order by created_at desc limit 200`,
        );
  return list.map(mapOrder);
}

async function paymentsFor(userId: string): Promise<PaymentRow[]> {
  const me = await requireRole(userId, ["cliente", "funcionario", "dono"]);
  const sql = await getSql();
  const rows =
    me.role === "dono" || me.role === "funcionario"
      ? await sql<{
          id: string;
          order_id: string;
          method: string;
          status: string;
          amount_aoa: unknown;
          created_at: unknown;
        }>`
          select id, order_id, method, status, amount_aoa, created_at
          from payments order by created_at desc limit 200
        `
      : await sql<{
          id: string;
          order_id: string;
          method: string;
          status: string;
          amount_aoa: unknown;
          created_at: unknown;
        }>`
          select p.id, p.order_id, p.method, p.status, p.amount_aoa, p.created_at
          from payments p
          join orders o on o.id = p.order_id
          where o.user_id = ${userId}
          order by p.created_at desc
          limit 200
        `;
  return rows.map((row) => ({
    id: row.id,
    orderId: row.order_id,
    method: row.method,
    status: row.status,
    amountAoa: asNum(row.amount_aoa),
    createdAt: asIso(row.created_at),
  }));
}

export const getPublicShop = createServerFn({ method: "GET" }).handler(async (): Promise<PublicShop> => {
  const [settings, services, promotions, ready] = await Promise.all([
    readSettings(),
    readServices(false),
    readPromos(false),
    ownerReady(),
  ]);
  return { settings, services, promotions, ownerReady: ready };
});

export const getSessionContext = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<SessionContext> => {
    const me = await profileOf(context.userId);
    return {
      role: me?.role ?? null,
      name: me?.name ?? "",
      phone: me?.phone ?? "",
      ownerReady: await ownerReady(),
    };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const name = str(data.name, 80);
    const phone = str(data.phone, 24);
    if (phone && !phoneDigitsOk(phone)) throw new Error("Indica um telefone válido.");
    return { name, phone };
  })
  .handler(async ({ context, data }): Promise<SessionContext> => {
    const sql = await getSql();
    const existing = await profileOf(context.userId);
    if (!existing) {
      if (!phoneDigitsOk(data.phone)) throw new Error("Indica um telefone válido.");
      const name = must(data.name, "Indica o teu nome.");
      await sql`
        insert into profiles (user_id, name, phone, role)
        values (${context.userId}, ${name}, ${data.phone}, 'cliente')
        on conflict (user_id) do nothing
      `;
    } else {
      await sql`
        update profiles
        set name = ${data.name || existing.name},
            phone = ${data.phone || existing.phone}
        where user_id = ${context.userId}
      `;
    }
    const me = await profileOf(context.userId);
    return {
      role: me?.role ?? null,
      name: me?.name ?? "",
      phone: me?.phone ?? "",
      ownerReady: await ownerReady(),
    };
  });

export const claimOwnership = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    return {
      code: str(data.code, 40),
      name: str(data.name, 80),
      phone: str(data.phone, 24),
    };
  })
  .handler(async ({ context, data }): Promise<SessionContext> => {
    const existing = await profileOf(context.userId);
    if (existing?.role === "dono") {
      return {
        role: "dono",
        name: existing.name,
        phone: existing.phone,
        ownerReady: true,
      };
    }
    if (data.code !== "PG-DONO-7K") throw new Error("Código do dono incorreto.");
    if (await ownerReady()) throw new Error("A gráfica já tem um dono.");
    if (data.phone && !phoneDigitsOk(data.phone)) throw new Error("Telefone inválido.");
    const name = data.name || existing?.name || "Responsável";
    const phone = data.phone || existing?.phone || "";
    const sql = await getSql();
    try {
      await sql`
        insert into profiles (user_id, name, phone, role)
        values (${context.userId}, ${name}, ${phone}, 'dono')
        on conflict (user_id) do update
        set role = 'dono',
            name = ${name},
            phone = case when ${phone} <> '' then ${phone} else profiles.phone end
      `;
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (/unique|duplicate/i.test(message)) throw new Error("A gráfica já tem um dono.");
      throw error;
    }
    return { role: "dono", name, phone, ownerReady: true };
  });

export const updateSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown): ShopSettings => {
    const data = obj(input);
    return {
      name: must(str(data.name, 60), "Indica o nome da gráfica."),
      tagline: str(data.tagline, 90) || "As tuas ideias ganham forma.",
      intro: str(data.intro, 280),
      about: str(data.about, 600),
      whatsapp: str(data.whatsapp, 24),
      address: str(data.address, 160),
      hours: str(data.hours, 120),
    };
  })
  .handler(async ({ context, data }): Promise<EditorData> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    await sql`
      update shop_settings
      set name = ${data.name},
          tagline = ${data.tagline},
          intro = ${data.intro},
          about = ${data.about},
          whatsapp = ${data.whatsapp},
          address = ${data.address},
          hours = ${data.hours}
      where id = 1
    `;
    return editorData();
  });

export const saveService = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const image = str(data.image, 120);
    if (!isAllowedImage(image)) throw new Error("Escolhe uma das imagens do catálogo.");
    return {
      id: intBetween(data.id, 0, 1_000_000, 0),
      name: must(str(data.name, 80), "Indica o nome do serviço."),
      description: str(data.description, 240),
      priceLabel: str(data.priceLabel, 40) || "A confirmar",
      image,
      sortOrder: intBetween(data.sortOrder, 0, 999, 0),
      visible: data.visible !== false,
    };
  })
  .handler(async ({ context, data }): Promise<EditorData> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    if (data.id) {
      await sql`
        update services
        set name = ${data.name},
            description = ${data.description},
            price_label = ${data.priceLabel},
            image = ${data.image},
            sort_order = ${data.sortOrder},
            visible = ${data.visible}
        where id = ${data.id}
      `;
    } else {
      await sql`
        insert into services (name, description, price_label, image, sort_order, visible)
        values (${data.name}, ${data.description}, ${data.priceLabel}, ${data.image}, ${data.sortOrder}, ${data.visible})
      `;
    }
    return editorData();
  });

export const deleteService = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const id = intBetween(data.id, 1, 1_000_000, 0);
    if (!id) throw new Error("Serviço em falta.");
    return { id };
  })
  .handler(async ({ context, data }): Promise<EditorData> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    await sql`delete from services where id = ${data.id}`;
    return editorData();
  });

export const savePromotion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    return {
      id: intBetween(data.id, 0, 1_000_000, 0),
      title: must(str(data.title, 80), "Indica o título da promoção."),
      body: str(data.body, 400),
      active: data.active !== false,
    };
  })
  .handler(async ({ context, data }): Promise<EditorData> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    if (data.id) {
      await sql`
        update promotions set title = ${data.title}, body = ${data.body}, active = ${data.active}
        where id = ${data.id}
      `;
    } else {
      await sql`
        insert into promotions (title, body, active) values (${data.title}, ${data.body}, ${data.active})
      `;
    }
    return editorData();
  });

export const deletePromotion = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const id = intBetween(obj(input).id, 1, 1_000_000, 0);
    if (!id) throw new Error("Promoção em falta.");
    return { id };
  })
  .handler(async ({ context, data }): Promise<EditorData> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    await sql`delete from promotions where id = ${data.id}`;
    return editorData();
  });

export const listOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<OrderSummary[]> => ordersFor(context.userId));

export const createOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const phone = str(data.phone, 24);
    if (!phoneDigitsOk(phone)) throw new Error("Indica um telefone válido.");
    const note = str(data.note, 1000);
    const file = fileOrNull(str(data.fileData, MAX_DATA_URL), str(data.fileName, 180));
    if (!note && !file.data) throw new Error("Escreve instruções ou anexa um ficheiro.");
    return {
      serviceName: must(str(data.serviceName, 80), "Escolhe um serviço."),
      qty: intBetween(data.qty, 1, 5000, 1),
      note,
      phone,
      file,
    };
  })
  .handler(async ({ context, data }): Promise<{ id: string; orders: OrderSummary[] }> => {
    const sql = await getSql();
    let me = await profileOf(context.userId);
    if (!me) {
      await sql`
        insert into profiles (user_id, name, phone, role)
        values (${context.userId}, ${"Cliente"}, ${data.phone}, 'cliente')
        on conflict (user_id) do nothing
      `;
      me = await profileOf(context.userId);
    }
    if (!me) throw new Error("Não foi possível criar o perfil.");
    const found = await sql<{ name: string }>`
      select name from services where name = ${data.serviceName} and visible = true limit 1
    `;
    if (!found[0]) throw new Error("Escolhe um serviço do catálogo.");
    const staff = await sql<{ name: string }>`
      select name from profiles where role = 'funcionario' order by name
    `;
    const counts = await sql<{ n: unknown }>`select count(*)::int as n from orders`;
    const assignee = staff.length ? staff[asNum(counts[0]?.n) % staff.length].name : "";
    const inserted = await sql<{ id: string }>`
      insert into orders (
        id, user_id, client_name, phone, service_name, qty, note, status, payment,
        file_name, file_data, assignee
      ) values (
        'PG-' || lpad(nextval('order_no_seq')::text, 4, '0'),
        ${context.userId},
        ${me.name},
        ${data.phone},
        ${found[0].name},
        ${data.qty},
        ${data.note},
        'Recebido',
        'Pendente',
        ${data.file.name},
        ${data.file.data},
        ${assignee}
      )
      returning id
    `;
    return { id: inserted[0].id, orders: await ordersFor(context.userId) };
  });

export const changeStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const status = str(data.status, 40);
    if (!isOneOf(status, ORDER_STATUSES)) throw new Error("Estado inválido.");
    return { orderId: must(str(data.orderId, 20), "Pedido em falta."), status };
  })
  .handler(async ({ context, data }): Promise<OrderSummary[]> => {
    await requireRole(context.userId, ["dono", "funcionario"]);
    const sql = await getSql();
    await sql`update orders set status = ${data.status} where id = ${data.orderId}`;
    return ordersFor(context.userId);
  });

export const submitPayment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const method = str(data.method, 40);
    if (!isOneOf(method, PAYMENT_METHODS)) throw new Error("Método inválido.");
    return {
      orderId: must(str(data.orderId, 20), "Escolhe o pedido."),
      method,
      amount: intBetween(data.amount, 0, 100_000_000, 0),
    };
  })
  .handler(async ({ context, data }): Promise<PaymentRow[]> => {
    const me = await requireRole(context.userId, ["cliente", "dono"]);
    const sql = await getSql();
    const orders = await sql<{ user_id: string; payment: string }>`
      select user_id, payment from orders where id = ${data.orderId} limit 1
    `;
    const order = orders[0];
    if (!order) throw new Error("Pedido não encontrado.");
    if (me.role === "cliente" && order.user_id !== context.userId) {
      throw new Error("Esse pedido não está na tua conta.");
    }
    const pending = await sql<{ id: string }>`
      select id from payments
      where order_id = ${data.orderId} and status = 'Por verificar'
      limit 1
    `;
    if (pending[0]) {
      await sql`
        update payments set method = ${data.method}, amount_aoa = ${data.amount}
        where id = ${pending[0].id}
      `;
    } else {
      await sql`
        insert into payments (id, order_id, user_id, method, status, amount_aoa)
        values (
          'PAY-' || lpad(nextval('payment_no_seq')::text, 4, '0'),
          ${data.orderId}, ${context.userId}, ${data.method}, 'Por verificar', ${data.amount}
        )
      `;
    }
    if (order.payment !== "Pago") {
      await sql`update orders set payment = 'Comprovativo enviado' where id = ${data.orderId}`;
    }
    return paymentsFor(context.userId);
  });

export const markPaid = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const method = str(data.method, 40) || "Pagamento presencial";
    if (!isOneOf(method, PAYMENT_METHODS)) throw new Error("Método inválido.");
    return {
      orderId: must(str(data.orderId, 20), "Pedido em falta."),
      method,
      amount: intBetween(data.amount, 0, 100_000_000, 0),
    };
  })
  .handler(async ({ context, data }): Promise<{ orders: OrderSummary[]; payments: PaymentRow[] }> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    const orders = await sql`select id from orders where id = ${data.orderId} limit 1`;
    if (!orders[0]) throw new Error("Pedido não encontrado.");
    const pending = await sql<{ id: string }>`
      select id from payments where order_id = ${data.orderId} and status = 'Por verificar'
      order by created_at desc limit 1
    `;
    if (pending[0]) {
      await sql`
        update payments set status = 'Confirmado', amount_aoa = ${data.amount}, method = ${data.method}
        where id = ${pending[0].id}
      `;
      await sql`
        delete from payments
        where order_id = ${data.orderId} and status = 'Por verificar' and id <> ${pending[0].id}
      `;
    } else {
      const confirmed = await sql<{ id: string }>`
        select id from payments where order_id = ${data.orderId} and status = 'Confirmado' limit 1
      `;
      if (confirmed[0]) {
        await sql`
          update payments set amount_aoa = ${data.amount}, method = ${data.method}
          where id = ${confirmed[0].id}
        `;
      } else {
        await sql`
          insert into payments (id, order_id, user_id, method, status, amount_aoa)
          values (
            'PAY-' || lpad(nextval('payment_no_seq')::text, 4, '0'),
            ${data.orderId}, ${context.userId}, ${data.method}, 'Confirmado', ${data.amount}
          )
        `;
      }
    }
    await sql`update orders set payment = 'Pago' where id = ${data.orderId}`;
    return { orders: await ordersFor(context.userId), payments: await paymentsFor(context.userId) };
  });

export const listPayments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<PaymentRow[]> => paymentsFor(context.userId));

export const getOrderAsset = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const kind = str(data.kind, 10);
    if (kind !== "source" && kind !== "final") throw new Error("Ficheiro inválido.");
    return { orderId: must(str(data.orderId, 20), "Pedido em falta."), kind };
  })
  .handler(async ({ context, data }): Promise<{ name: string; dataUrl: string }> => {
    const me = await profileOf(context.userId);
    if (!me) throw new Error("Sem permissão.");
    const sql = await getSql();
    const rows = await sql<{
      user_id: string;
      file_name: string;
      file_data: string | null;
      final_name: string;
      final_data: string | null;
    }>`
      select user_id, file_name, file_data, final_name, final_data
      from orders where id = ${data.orderId} limit 1
    `;
    const order = rows[0];
    if (!order) throw new Error("Pedido não encontrado.");
    const staff = me.role === "dono" || me.role === "funcionario";
    if (!staff && order.user_id !== context.userId) throw new Error("Sem permissão.");
    const dataUrl = data.kind === "final" ? order.final_data : order.file_data;
    const name = data.kind === "final" ? order.final_name : order.file_name;
    if (!dataUrl) throw new Error("Este pedido não tem esse ficheiro.");
    return { name: name || "ficheiro", dataUrl };
  });

export const attachFinal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const file = fileOrNull(str(data.dataUrl, MAX_DATA_URL), str(data.name, 180));
    if (!file.data) throw new Error("Anexa o ficheiro final.");
    return { orderId: must(str(data.orderId, 20), "Pedido em falta."), file };
  })
  .handler(async ({ context, data }): Promise<OrderSummary[]> => {
    await requireRole(context.userId, ["dono", "funcionario"]);
    const sql = await getSql();
    const updated = await sql`
      update orders set final_name = ${data.file.name}, final_data = ${data.file.data}
      where id = ${data.orderId}
      returning id
    `;
    if (!updated[0]) throw new Error("Pedido não encontrado.");
    return ordersFor(context.userId);
  });

export const listThreads = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ThreadSummary[]> => {
    await requireRole(context.userId, ["dono", "funcionario"]);
    const sql = await getSql();
    const people = await sql<{ user_id: string; name: string; phone: string; created_at: unknown }>`
      select user_id, name, phone, created_at from profiles
      where role = 'cliente'
      order by created_at desc
      limit 100
    `;
    const last = await sql<{ thread_user_id: string; body: string; created_at: unknown }>`
      select distinct on (thread_user_id) thread_user_id, body, created_at
      from messages
      order by thread_user_id, created_at desc
    `;
    const byThread = new Map(last.map((row) => [row.thread_user_id, row]));
    return people
      .map((person) => {
        const message = byThread.get(person.user_id);
        return {
          userId: person.user_id,
          name: person.name,
          phone: person.phone,
          lastBody: message?.body ?? "",
          lastAt: asIso(message?.created_at ?? person.created_at),
        };
      })
      .sort((a, b) => (a.lastAt < b.lastAt ? 1 : -1));
  });

export const listMessages = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => ({ threadUserId: str(obj(input).threadUserId, 80) }))
  .handler(async ({ context, data }): Promise<ChatMessage[]> => {
    const me = await profileOf(context.userId);
    if (!me) throw new Error("Completa o teu perfil primeiro.");
    const thread = me.role === "cliente" ? context.userId : data.threadUserId;
    if (!thread) return [];
    const sql = await getSql();
    const rows = await sql<{
      id: unknown;
      thread_user_id: string;
      author_id: string;
      author_name: string;
      author_role: string;
      body: string;
      created_at: unknown;
    }>`
      select id, thread_user_id, author_id, author_name, author_role, body, created_at
      from messages where thread_user_id = ${thread}
      order by created_at asc
      limit 300
    `;
    return rows.map((row) => ({
      id: asNum(row.id),
      threadUserId: row.thread_user_id,
      authorId: row.author_id,
      authorName: row.author_name,
      authorRole: row.author_role,
      body: row.body,
      createdAt: asIso(row.created_at),
    }));
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    return {
      threadUserId: str(data.threadUserId, 80),
      body: must(str(data.body, 1000), "Escreve a mensagem."),
    };
  })
  .handler(async ({ context, data }): Promise<ChatMessage[]> => {
    const me = await profileOf(context.userId);
    if (!me) throw new Error("Completa o teu perfil primeiro.");
    const thread = me.role === "cliente" ? context.userId : data.threadUserId;
    if (!thread) throw new Error("Escolhe a conversa.");
    if (me.role !== "cliente") {
      const target = await profileOf(thread);
      if (!target) throw new Error("Cliente não encontrado.");
    }
    const sql = await getSql();
    await sql`
      insert into messages (thread_user_id, author_id, author_name, author_role, body)
      values (${thread}, ${context.userId}, ${me.name}, ${me.role}, ${data.body})
    `;
    const rows = await sql<{
      id: unknown;
      thread_user_id: string;
      author_id: string;
      author_name: string;
      author_role: string;
      body: string;
      created_at: unknown;
    }>`
      select id, thread_user_id, author_id, author_name, author_role, body, created_at
      from messages where thread_user_id = ${thread}
      order by created_at asc limit 300
    `;
    return rows.map((row) => ({
      id: asNum(row.id),
      threadUserId: row.thread_user_id,
      authorId: row.author_id,
      authorName: row.author_name,
      authorRole: row.author_role,
      body: row.body,
      createdAt: asIso(row.created_at),
    }));
  });

export const listTeam = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<TeamMember[]> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    const rows = await sql<{
      user_id: string;
      name: string;
      email: string;
      phone: string;
      role: string;
    }>`
      select u.id as user_id, u.name, u.email, coalesce(p.phone, '') as phone,
             coalesce(p.role, 'cliente') as role
      from "user" u
      left join profiles p on p.user_id = u.id
      order by u."createdAt" desc
    `;
    return rows.flatMap((row) => {
      const role = asRole(row.role) ?? "cliente";
      return [{ userId: row.user_id, name: row.name, email: row.email, phone: row.phone, role }];
    });
  });

export const setMemberRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const data = obj(input);
    const role = str(data.role, 20);
    if (role !== "cliente" && role !== "funcionario") {
      throw new Error("Só podes atribuir cliente ou funcionário.");
    }
    return { email: must(str(data.email, 120).toLowerCase(), "Indica o e-mail."), role };
  })
  .handler(async ({ context, data }): Promise<TeamMember[]> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    const users = await sql<{ id: string; name: string }>`
      select id, name from "user" where lower(email) = ${data.email} limit 1
    `;
    const user = users[0];
    if (!user) {
      throw new Error("Não há conta com esse e-mail. A pessoa tem de se registar primeiro como cliente.");
    }
    if (user.id === context.userId) throw new Error("Não podes alterar o teu próprio acesso aqui.");
    const existing = await profileOf(user.id);
    if (existing?.role === "dono") throw new Error("O dono não pode ser alterado.");
    await sql`
      insert into profiles (user_id, name, phone, role)
      values (${user.id}, ${existing?.name || user.name}, ${existing?.phone || ""}, ${data.role})
      on conflict (user_id) do update set role = ${data.role}
    `;
    const rows = await sql<{
      user_id: string;
      name: string;
      email: string;
      phone: string;
      role: string;
    }>`
      select u.id as user_id, u.name, u.email, coalesce(p.phone, '') as phone,
             coalesce(p.role, 'cliente') as role
      from "user" u
      left join profiles p on p.user_id = u.id
      order by u."createdAt" desc
    `;
    return rows.flatMap((row) => {
      const role = asRole(row.role) ?? "cliente";
      return [{ userId: row.user_id, name: row.name, email: row.email, phone: row.phone, role }];
    });
  });

export const getReports = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ReportData> => {
    await requireRole(context.userId, ["dono"]);
    const sql = await getSql();
    const counts = await sql<{ orders: unknown; done: unknown }>`
      select count(*)::int as orders,
             count(*) filter (where status = 'Concluído')::int as done
      from orders
    `;
    const money = await sql<{ n: unknown; total: unknown }>`
      select count(*)::int as n, coalesce(sum(amount_aoa), 0)::int as total
      from payments where status = 'Confirmado'
    `;
    const rows = await sql<{
      id: string;
      client_name: string;
      service_name: string;
      status: string;
      payment: string;
      created_at: unknown;
    }>`
      select id, client_name, service_name, status, payment, created_at
      from orders order by created_at desc limit 200
    `;
    return {
      orders: asNum(counts[0]?.orders),
      done: asNum(counts[0]?.done),
      confirmed: asNum(money[0]?.n),
      revenue: asNum(money[0]?.total),
      rows: rows.map((row) => ({
        id: row.id,
        clientName: row.client_name,
        serviceName: row.service_name,
        status: row.status,
        payment: row.payment,
        createdAt: asIso(row.created_at),
      })),
    };
  });
