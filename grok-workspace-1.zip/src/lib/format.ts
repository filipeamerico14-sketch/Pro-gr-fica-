export function explain(err: unknown): string {
  const msg = err instanceof Error ? err.message : "";
  if (!msg) return "Não foi possível concluir. Tenta outra vez.";
  if (/unauthorized/i.test(msg)) return "A sessão expirou. Entra novamente.";
  return msg;
}

export function formatAoa(value: number) {
  return `${new Intl.NumberFormat("pt-PT").format(value)} AOA`;
}

export function formatWhen(iso: string) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat("pt-PT", {
    timeZone: "Africa/Luanda",
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

export function waHref(raw: string) {
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 8) return null;
  return `https://wa.me/${digits}`;
}

export function phoneOk(value: string) {
  return value.replace(/\D/g, "").length >= 9;
}
