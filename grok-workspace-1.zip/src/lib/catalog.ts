export const HERO_IMAGE = "/photos/hero.jpg";

export const SERVICE_IMAGES = [
  { src: "/photos/impressao.jpg", label: "Impressão" },
  { src: "/photos/design.jpg", label: "Design" },
  { src: "/photos/cartoes.jpg", label: "Cartões" },
  { src: "/photos/digitalizacao.jpg", label: "Digitalização" },
  { src: "/photos/encadernacao.jpg", label: "Encadernação" },
  { src: "/photos/plastificacao.jpg", label: "Acabamento" },
] as const;

export function isAllowedImage(src: string) {
  return SERVICE_IMAGES.some((item) => item.src === src);
}
