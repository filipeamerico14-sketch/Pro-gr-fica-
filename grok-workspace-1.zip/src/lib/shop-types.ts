export const ORDER_STATUSES = [
  "Recebido",
  "Em produção",
  "A aguardar pagamento",
  "Concluído",
] as const;

export const PAYMENT_STATES = ["Pendente", "Comprovativo enviado", "Pago"] as const;

export const PAYMENT_METHODS = [
  "Multicaixa Express",
  "Transferência bancária",
  "Pagamento presencial",
] as const;

export type Role = "cliente" | "funcionario" | "dono";
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export type PaymentState = (typeof PAYMENT_STATES)[number];
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];

export type ShopSettings = {
  name: string;
  tagline: string;
  intro: string;
  about: string;
  whatsapp: string;
  address: string;
  hours: string;
};

export type ShopService = {
  id: number;
  name: string;
  description: string;
  priceLabel: string;
  image: string;
  sortOrder: number;
  visible: boolean;
};

export type Promotion = {
  id: number;
  title: string;
  body: string;
  active: boolean;
};

export type PublicShop = {
  settings: ShopSettings;
  services: ShopService[];
  promotions: Promotion[];
  ownerReady: boolean;
};

export type EditorData = {
  settings: ShopSettings;
  services: ShopService[];
  promotions: Promotion[];
};

export type SessionContext = {
  role: Role | null;
  name: string;
  phone: string;
  ownerReady: boolean;
};

export type OrderSummary = {
  id: string;
  userId: string;
  clientName: string;
  phone: string;
  serviceName: string;
  qty: number;
  note: string;
  status: string;
  payment: string;
  fileName: string;
  finalName: string;
  assignee: string;
  createdAt: string;
  hasFile: boolean;
  hasFinal: boolean;
};

export type PaymentRow = {
  id: string;
  orderId: string;
  method: string;
  status: string;
  amountAoa: number;
  createdAt: string;
};

export type ChatMessage = {
  id: number;
  threadUserId: string;
  authorId: string;
  authorName: string;
  authorRole: string;
  body: string;
  createdAt: string;
};

export type ThreadSummary = {
  userId: string;
  name: string;
  phone: string;
  lastBody: string;
  lastAt: string;
};

export type TeamMember = {
  userId: string;
  name: string;
  email: string;
  phone: string;
  role: Role;
};

export type ReportData = {
  orders: number;
  done: number;
  confirmed: number;
  revenue: number;
  rows: Array<{
    id: string;
    clientName: string;
    serviceName: string;
    status: string;
    payment: string;
    createdAt: string;
  }>;
};

export function isOneOf<T extends string>(value: string, list: readonly T[]): value is T {
  return (list as readonly string[]).includes(value);
}
