export const MAX_UPLOAD_BYTES = 600_000;

export function readUpload(file: File): Promise<{ name: string; dataUrl: string }> {
  if (file.size > MAX_UPLOAD_BYTES) {
    return Promise.reject(
      new Error("O ficheiro passa de 600 KB. Comprime-o ou envia um PDF mais leve."),
    );
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result || "");
      if (!dataUrl.startsWith("data:")) {
        reject(new Error("Não foi possível ler o ficheiro."));
        return;
      }
      resolve({ name: file.name, dataUrl });
    };
    reader.onerror = () => reject(new Error("Não foi possível ler o ficheiro."));
    reader.readAsDataURL(file);
  });
}
